﻿ClockSimpleJEE4是开源例程企业考勤系统
用于Java,mysql学习。
所有程序在GPLv3条款下开源，关于GPLv3相关pdf已放置在doc子目录下。
数据库脚本在sql子目录下。请恢复名为clock的产品库和名为clock_test的测试库。
clock_test是用于单元测试的JUnit套件的测试空库。
请启动测试套件，享受105个测试方法编织的绵密的测试网。、
可以启动JUnitEE测试套件 http://localhost:8080/clocksimplejee4/TestServlet
doc下另有所有版本的release note和部分截图。
本软件力推如下的JUnit测试黄金法则：在测试空库上无限次运行不出错。
bug报告jerry_shen_sjf@qq.com
用如下管理员登录
用户名：160208
密码：jerry

火鸟
2015.1.5

