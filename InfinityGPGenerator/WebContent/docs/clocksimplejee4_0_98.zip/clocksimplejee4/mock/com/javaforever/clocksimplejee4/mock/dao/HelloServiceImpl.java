package com.javaforever.clocksimplejee4.mock.dao;

public class HelloServiceImpl implements IHelloService {
    public String sayHelloToSomebody(String name) {
	         return "HELLO," + name + "!";
	     }
	 
	 } 
