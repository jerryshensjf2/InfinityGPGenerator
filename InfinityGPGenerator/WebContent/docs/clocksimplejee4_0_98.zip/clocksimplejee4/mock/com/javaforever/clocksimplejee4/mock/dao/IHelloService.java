package com.javaforever.clocksimplejee4.mock.dao;

public interface IHelloService {
	  

	   String sayHelloToSomebody(String name);
	 
}